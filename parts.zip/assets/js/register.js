window.onload = () => {
    console.log("Register now....");
   document.getElementById("profile").addEventListener("click", () => {
       var element_input = document.getElementById("fileUpload");
       if( element_input && document.createEvent){
            var event_ = document.createEvent("MouseEvent");
            event_.initEvent("click", true, false);
            element_input.dispatchEvent(event_);
       }
   });
   
};

function setPicture(event){
    var selectedFile = event.target.files[0];
    var fileReaderImg = new FileReader();
    var imageTag = document.getElementById("image");
    fileReaderImg.onload = function(event){
        imageTag.src = event.target.result;
    }
    fileReaderImg.readAsDataURL(selectedFile);
  
}