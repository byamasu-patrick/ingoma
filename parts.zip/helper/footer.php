
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="text-center" style="margin: 0px;">Partners</p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-3"><a href="#"><img class="img-fluid d-block mx-auto" src="assets/img/WhatsApp%20Image%202020-01-09%20at%202.48.25%20PM.jpeg" height="20px" width="200px" style="height: 80px;width: auto;"></a></div>
                <div class="col-sm-6 col-md-3"><a href="#"></a><img class="img-fluid d-block mx-auto" src="assets/img/WhatsApp%20Image%202019-08-23%20at%2012.31.49%20PM.jpeg" style="height: 80px;width: auto;"></div>
                <div class="col-sm-6 col-md-3"><a href="#"><img class="img-fluid d-block mx-auto" src="assets/img/FlaotMusic.jpg" style="height: 80px;width: auto;"></a></div>
                <div class="col-sm-6 col-md-3"><a href="#"><img class="img-fluid d-block mx-auto" src="assets/img/Tumaini-Letu-Logo-768x543.png" style="height: 80px;width: auto;"></a></div>
            </div>
        </div>
    </section>
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4"><span class="copyright">Copyright&nbsp;© ingoma 2020</span></div>
                <div class="col-md-4">
                    <ul class="list-inline social-buttons">
                        <li class="list-inline-item"><a href="http://twitter.com/GakwayaRemy"><i class="fa fa-twitter"></i></a></li>
                        <li class="list-inline-item"><a href="https://www.facebook.com/gakwayarem"><i class="fa fa-facebook"></i></a></li>
                        <li class="list-inline-item"><a href="https://www.linkedin.com/in/gakwayaremy/"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="list-inline quicklinks">
                        <li class="list-inline-item"><a href="#">Powered by takenoLAB</a></li>
                        <li class="list-inline-item"></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>